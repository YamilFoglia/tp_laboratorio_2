int close();
void limpiarBuffer();
void limpiarPantalla();

void pausa();

void defaultError();

void bienvenida();

void menu();

int opcion();

int compararPorID(void* empleado1, void* empleado2);

int compararPorHorasTrabajadas(void* empleado1, void* empleado2);

int compararPorSueldo(void* empleado1, void* empleado2);

int compararPorNombre(void* empleado1, void* empleado2);

int obtenerIdMasGrande(LinkedList* lista);

